1. console.firebase.google.com -> nowy projekt -> dodaj aplikacje webowa -> skopiuj firebaseConfig
2. Wklej go na gorze index.html w miejsce TU_WKLEJ
3. Authentication -> Sign-in method -> wlacz Email/Password
4. Firestore Database -> utworz baze -> Rules -> wklej zawartosc firestore.rules -> Publish
5. Wgraj index.html i logo.png na GitHub
6. Zarejestruj nick kapiello jako pierwszy (to konto admina)
